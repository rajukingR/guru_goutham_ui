import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Checkbox,
} from "@mui/material";
import axios from "axios";
import { Snackbar, Alert } from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";

import API_URL from "../../../api/Api_url";

const BrandsPageEditLayout = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [form, setForm] = useState({
    brandNumber: "",
    brandName: "",
    description: "",
    active: false,
  });

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  useEffect(() => {
    const fetchBrand = async () => {
      try {
        const response = await axios.get(`${API_URL}/product-brands/${id}`);
        const brandData = response.data;
        
        setForm({
          brandNumber: brandData.brand_number,
          brandName: brandData.brand_name,
          description: brandData.brand_description,
          active: brandData.active_status,
        });
      } catch (error) {
        console.error("Error fetching brand:", error);
        setSnackbar({
          open: true,
          message: "Failed to load brand data. Please try again.",
          severity: "error",
        });
      }
    };

    fetchBrand();
  }, [id]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === "checkbox" ? checked : value });
  };

  const handleSubmit = async () => {
    const payload = {
      brand_number: form.brandNumber,
      brand_name: form.brandName,
      brand_description: form.description,
      active_status: form.active,
    };

    try {
      const response = await axios.put(`${API_URL}/product-brands/${id}`, payload);
      if (response.status === 200 || response.status === 201) {
        setSnackbar({
          open: true,
          message: "Brand updated successfully!",
          severity: "success",
        });
        setTimeout(() => {
          navigate("/dashboard/product_library/brands");
        }, 1500);
      }
    } catch (error) {
      console.error("Error updating brand:", error);
      setSnackbar({
        open: true,
        message: "Failed to update brand. Please try again.",
        severity: "error",
      });
    }
  };

  const containerStyle = {
    padding: '2rem',
    fontFamily: '"Inter", "Segoe UI", -apple-system, BlinkMacSystemFont, sans-serif',
    minHeight: '100vh',
    lineHeight: 1.6,
  };

  const cardStyle = {
    backgroundColor: '#ffffff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1), 0 1px 2px rgba(0, 0, 0, 0.06)',
    border: '1px solid #e2e8f0',
    maxWidth: '800px',
    margin: '0',
  };

  const cardHeaderContainerStyle = {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '1.5rem',
    paddingBottom: '1rem',
    borderBottom: '1px solid #e2e8f0',
  };

  const iconStyle = {
    fontSize: '1.25rem',
    marginRight: '0.75rem',
    backgroundColor: '#f1f5f9',
    padding: '0.5rem',
    borderRadius: '8px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  const cardHeaderStyle = {
    fontSize: '1.125rem',
    fontWeight: '600',
    color: '#1e293b',
    margin: 0,
  };

  const fieldsGridStyle = {
    display: 'grid',
    gap: '1rem',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
  };

  const fieldContainerStyle = {
    display: 'flex',
    flexDirection: 'column',
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '0.5rem',
    fontWeight: '500',
    fontSize: '0.875rem',
    color: '#374151',
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '8px',
    border: '1px solid #d1d5db',
    fontSize: '0.875rem',
    backgroundColor: '#ffffff',
  };

  const checkboxContainerStyle = {
    marginTop: '0.5rem',
  };

  const checkboxLabelStyle = {
    display: 'flex',
    alignItems: 'flex-start',
    cursor: 'pointer',
    gap: '0.75rem',
  };

  const checkboxStyle = {
    display: 'none',
  };

  const checkboxCustomStyle = {
    width: '20px',
    height: '20px',
    borderRadius: '4px',
    border: form.active ? '2px solid #2563eb' : '2px solid #d1d5db',
    backgroundColor: form.active ? '#2563eb' : '#ffffff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const checkmarkStyle = {
    color: '#ffffff',
    fontSize: '12px',
    fontWeight: 'bold',
    display: form.active ? 'block' : 'none',
  };

  const checkboxTextStyle = {
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  };

  const buttonContainerStyle = {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '0.75rem',
    marginTop: '2rem',
  };

  const cancelBtnStyle = {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#f3f4f6',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    cursor: 'pointer',
  };

  const createBtnStyle = {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#2563eb',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
  };

  return (
    <div style={containerStyle}>
      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
      
      <div style={cardStyle}>
        <div style={cardHeaderContainerStyle}>
          <div style={iconStyle}>✏️</div>
          <h3 style={cardHeaderStyle}>Edit Brand</h3>
        </div>
        
        <div style={fieldsGridStyle}>
          <Field
            label="Brand Number"
            type="text"
            name="brandNumber"
            value={form.brandNumber}
            onChange={handleChange}
            fieldContainerStyle={fieldContainerStyle}
            labelStyle={labelStyle}
            inputStyle={inputStyle}
          />
          <Field
            label="Brand Name"
            type="text"
            name="brandName"
            value={form.brandName}
            onChange={handleChange}
            fieldContainerStyle={fieldContainerStyle}
            labelStyle={labelStyle}
            inputStyle={inputStyle}
          />
          <Field
            label="Brand Description"
            type="text"
            name="description"
            value={form.description}
            onChange={handleChange}
            fieldContainerStyle={fieldContainerStyle}
            labelStyle={labelStyle}
            inputStyle={inputStyle}
          />
          <div style={checkboxContainerStyle}>
            <label style={checkboxLabelStyle}>
              <Checkbox
                name="active"
                checked={form.active}
                onChange={handleChange}
                style={checkboxStyle}
              />
              <div style={checkboxCustomStyle}>
                <span style={checkmarkStyle}>✓</span>
              </div>
              <div>
                <span style={checkboxTextStyle}>Active Status</span>
              </div>
            </label>
          </div>
        </div>
        
        <div style={buttonContainerStyle}>
          <button style={cancelBtnStyle} onClick={() => navigate("/dashboard/product_library/brands")}>
            Cancel
          </button>
          <button style={createBtnStyle} onClick={handleSubmit}>
            Update
          </button>
        </div>
      </div>
    </div>
  );
};

const Field = ({ label, type = 'text', value = '', name, onChange, fieldContainerStyle, labelStyle, inputStyle }) => (
  <div style={fieldContainerStyle}>
    <label style={labelStyle}>
      {label}
    </label>
    <input
      type={type}
      value={value}
      name={name}
      onChange={onChange}
      style={inputStyle}
    />
  </div>
);

export default BrandsPageEditLayout;